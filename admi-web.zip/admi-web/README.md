# ADMI Score (web tool)

A single-page tool like the RPDI scorer: Methodology, Scoring rules, Tool, Statistics and Data tabs. Pick any origin airport, pick destinations (one airport, all US states, all countries, one continent, or your own list), pick 7 to 10 dates, and fetch fares automatically.

## What is tested and what is not
- **Tested here (headless browser, stubbed fare service):** origin and destination selection, date suggestion, the fetch loop with pause and resume, storage across reloads, scoring (matches the verification table: 1.000 and 0.191), the benchmark baseline, CSV export, and the server function against SerpApi-shaped responses.
- **Not tested:** a real call to SerpApi. It could not be reached from the build environment and no key was available. Run the 3-route trial below first.

## Deploy (about 10 minutes)
1. Put these files in a new Git repository (or a new folder in your existing one) exactly as they are: `index.html`, `airports.js`, `api/search.js`.
2. Import it as a new project in Vercel.
3. In the project's Settings → Environment Variables add:
   - `SERPAPI_KEY`: your key from serpapi.com
   - `ADMI_ACCESS_CODE`: any passphrase. Without it, anyone who finds the URL can spend your search credits.
4. Redeploy. Open the site, go to the Tool tab, and type the same passphrase in the Access code box.

## First run
1. Origin: your airport. Destinations: "My own list", enter 3 codes. Dates: suggest 8, remove all but 1 or 2.
2. Fetch live prices. If three rows come back with fares and carrier names, the connection works.
3. Then run the full set.

## Cost warning
Searches = destinations × dates. All US states × 8 dates = 392. One continent × 8 is roughly 300 to 400. **All countries × 8 is about 1,480.** The tool shows the count and asks you to confirm before it spends anything. Results are stored, so nothing is searched twice. Check your plan's monthly limit on serpapi.com first.

## Data lives in your browser
Fares are saved in IndexedDB in the browser you use. Clearing site data deletes them. Data → Download backup after every session.

## Distance checker
Distances are always computed from airport coordinates. Data → Distance checker compares your own distances (pasted lines like `BHM, 134`, or rows copied from your sheet) against the computed ones and flags any more than 5% off. Run on the ATL sheet it flags exactly the four routes listed below.

## Data to check
- **Airports:** one most-used airport per country was chosen from general knowledge. Airports marked "?" in the destination list are the ones I am least sure about. Fix any with Data → Add airport.
- **Distances** come from airport coordinates (great-circle). Compared with your ATL sheet, 45 of 49 US states agree within 5%. Four do not: Delaware (ILG: 642 vs 740 in the sheet), Michigan (DTW: 595 vs 540), Mississippi (JAN: 340 vs 265) and North Dakota (FAR: 1123 vs 985). Recheck those four in the sheet. The sheet also has "FDS" for Sioux Falls, South Dakota; the code is FSD.
- **Scope:** the $0.15/mile baseline and the carrier tiers were set for U.S. domestic fares in dollars. Other origins and international routes run fine but are exploratory, and the Methodology tab says so.
